"""
NIST SP 800-22 Randomness Test Suite
Ring-Oscillator TRNG Validation

Implements 4 core NIST SP 800-22 statistical tests:
  1. Frequency (Monobit) Test
  2. Block Frequency Test
  3. Runs Test
  4. Longest Run of Ones in a Block Test

Usage:
  python nist_test.py                        # runs on included test_bits.txt
  python nist_test.py --input your_bits.txt  # runs on your own bit file
  python nist_test.py --generate             # generates sample bits (Gaussian jitter model)

Reference: NIST SP 800-22 Rev 1a
  https://csrc.nist.gov/publications/detail/sp/800-22/rev-1a/final
"""

import math
import argparse
import os
import sys
from pathlib import Path

try:
    import numpy as np
    from scipy import special
    SCIPY_AVAILABLE = True
except ImportError:
    print("Installing required packages...")
    os.system(f"{sys.executable} -m pip install numpy scipy -q")
    import numpy as np
    from scipy import special
    SCIPY_AVAILABLE = True


# ─────────────────────────────────────────────────────────────
# Bit sequence I/O
# ─────────────────────────────────────────────────────────────

def load_bits(filepath: str) -> list[int]:
    """Load bits from a text file — accepts 0/1 strings, space-separated, or raw binary."""
    path = Path(filepath)
    if not path.exists():
        raise FileNotFoundError(f"Bit file not found: {filepath}")
    text = path.read_text().strip()
    # Remove whitespace and newlines, keep only 0s and 1s
    bits = [int(c) for c in text if c in '01']
    if len(bits) < 100:
        raise ValueError(f"Too few bits ({len(bits)}). Need at least 100 for meaningful tests.")
    return bits


def generate_simulated_bits(n: int = 10000, jitter_sigma_ps: float = 50.0) -> list[int]:
    """
    Generate synthetic TRNG bits using a Gaussian jitter model.

    Physical basis:
      - Ring oscillator period T0 = 1.54 ns (650 MHz nominal)
      - Gaussian jitter σ = 50 ps (realistic for 180nm CMOS)
      - Two oscillators accumulate relative jitter
      - D-FF samples XOR of outputs → bit = 1 if phase diff > T0/2

    This mirrors real hardware without needing Spectre output.
    """
    rng = np.random.default_rng(seed=None)  # truly random seed
    T0_ps = 1538.0          # period in ps (650 MHz)
    sigma_rel = jitter_sigma_ps * math.sqrt(2)  # relative jitter between two oscillators
    phase_diff = rng.normal(loc=T0_ps / 2, scale=sigma_rel, size=n)
    bits = (phase_diff % T0_ps > T0_ps / 2).astype(int).tolist()
    return bits


def save_bits(bits: list[int], filepath: str):
    """Save bit sequence to file."""
    Path(filepath).write_text(''.join(str(b) for b in bits))
    print(f"  Saved {len(bits)} bits → {filepath}")


# ─────────────────────────────────────────────────────────────
# NIST SP 800-22 Tests
# ─────────────────────────────────────────────────────────────

ALPHA = 0.01  # significance level — NIST standard

def _erfc(x):
    return special.erfc(x)

def _igamc(a, x):
    """Regularized upper incomplete gamma function."""
    return special.gammaincc(a, x)


def test_frequency_monobit(bits: list[int]) -> dict:
    """
    NIST Test 1: Frequency (Monobit) Test
    
    Purpose: Check that the proportion of 1s is approximately 50%.
    A perfectly random sequence has p(1) = p(0) = 0.5.
    """
    n = len(bits)
    s_n = sum(1 if b == 1 else -1 for b in bits)  # +1 for 1, -1 for 0
    s_obs = abs(s_n) / math.sqrt(n)
    p_value = _erfc(s_obs / math.sqrt(2))
    ones = sum(bits)
    return {
        "name": "Frequency (Monobit)",
        "p_value": p_value,
        "pass": p_value >= ALPHA,
        "detail": f"Ones count: {ones:,} / {n:,} ({100*ones/n:.2f}%)"
    }


def test_block_frequency(bits: list[int], M: int = 128) -> dict:
    """
    NIST Test 2: Frequency Test within a Block
    
    Purpose: Check that the proportion of 1s within M-bit blocks
    is approximately 50% in each block. Catches local biases.
    """
    n = len(bits)
    N = n // M  # number of complete blocks
    if N < 1:
        return {"name": "Block Frequency", "p_value": None, "pass": False, "detail": "Sequence too short"}

    chi_sq = 0.0
    for i in range(N):
        block = bits[i*M : (i+1)*M]
        pi_i = sum(block) / M
        chi_sq += (pi_i - 0.5) ** 2
    chi_sq *= 4 * M

    p_value = _igamc(N / 2, chi_sq / 2)
    return {
        "name": f"Block Frequency (M={M})",
        "p_value": p_value,
        "pass": p_value >= ALPHA,
        "detail": f"Blocks: {N}, χ² = {chi_sq:.4f}"
    }


def test_runs(bits: list[int]) -> dict:
    """
    NIST Test 3: Runs Test
    
    Purpose: Check the total number of runs (uninterrupted sequences
    of identical bits). Tests oscillation between 0s and 1s.
    A run is a maximal sequence of identical consecutive bits.
    """
    n = len(bits)
    pi = sum(bits) / n

    # Pre-test: check proportion is close enough to 0.5
    if abs(pi - 0.5) >= (2 / math.sqrt(n)):
        return {
            "name": "Runs",
            "p_value": 0.0,
            "pass": False,
            "detail": f"Pre-test failed: proportion {pi:.4f} too far from 0.5"
        }

    v_obs = 1 + sum(1 for i in range(n-1) if bits[i] != bits[i+1])
    numerator = abs(v_obs - 2*n*pi*(1-pi))
    denominator = 2 * math.sqrt(2*n) * pi * (1-pi)
    p_value = _erfc(numerator / denominator)
    return {
        "name": "Runs",
        "p_value": p_value,
        "pass": p_value >= ALPHA,
        "detail": f"Total runs: {v_obs:,}"
    }


def test_longest_run(bits: list[int]) -> dict:
    """
    NIST Test 4: Test for the Longest Run of Ones in a Block
    
    Purpose: Detect anomalies in the longest run of 1s.
    Uses 8-bit blocks for sequences of length 128–6271.
    """
    n = len(bits)
    # Parameters for n in [128, 6271]
    M = 8
    K = 3
    N = n // M
    if N < 1:
        return {"name": "Longest Run of Ones", "p_value": None, "pass": False, "detail": "Too short"}

    # Expected probabilities for block size M=8
    pi_k = [0.2148, 0.3672, 0.2305, 0.1875]  # for runs ≤1, 2, 3, ≥4

    v = [0, 0, 0, 0]  # counts for each category
    for i in range(N):
        block = bits[i*M : (i+1)*M]
        max_run = 0
        cur_run = 0
        for b in block:
            if b == 1:
                cur_run += 1
                max_run = max(max_run, cur_run)
            else:
                cur_run = 0
        # Categorize
        if max_run <= 1:
            v[0] += 1
        elif max_run == 2:
            v[1] += 1
        elif max_run == 3:
            v[2] += 1
        else:
            v[3] += 1

    chi_sq = sum((v[i] - N * pi_k[i])**2 / (N * pi_k[i]) for i in range(K+1))
    p_value = _igamc(K / 2, chi_sq / 2)
    return {
        "name": "Longest Run of Ones (block=8)",
        "p_value": p_value,
        "pass": p_value >= ALPHA,
        "detail": f"χ² = {chi_sq:.4f}, categories: {v}"
    }


# ─────────────────────────────────────────────────────────────
# Runner + pretty output
# ─────────────────────────────────────────────────────────────

def run_all_tests(bits: list[int]) -> list[dict]:
    return [
        test_frequency_monobit(bits),
        test_block_frequency(bits),
        test_runs(bits),
        test_longest_run(bits),
    ]


def estimate_min_entropy(bits: list[int]) -> float:
    """
    Estimate min-entropy H_inf from the most frequent byte value.
    H_inf = -log2(p_max) where p_max = most common pattern probability.
    """
    n = len(bits)
    if n < 8:
        return 0.0
    bytes_ = []
    for i in range(0, n - 7, 8):
        val = int(''.join(str(b) for b in bits[i:i+8]), 2)
        bytes_.append(val)
    from collections import Counter
    counts = Counter(bytes_)
    p_max = counts.most_common(1)[0][1] / len(bytes_)
    return -math.log2(p_max)


def print_results(results: list[dict], bits: list[int]):
    n = len(bits)
    sep = "=" * 60
    print(f"\n{sep}")
    print("NIST SP 800-22 Randomness Test Results")
    print(f"Sequence length: {n:,} bits")
    print(sep)

    all_pass = True
    for i, r in enumerate(results, 1):
        pv = r['p_value']
        pv_str = f"{pv:.4f}" if pv is not None else "N/A"
        status = "PASS ✓" if r['pass'] else "FAIL ✗"
        if not r['pass']:
            all_pass = False
        print(f"\nTest {i}: {r['name']}")
        print(f"  {r['detail']}")
        print(f"  p-value : {pv_str}")
        print(f"  Result  : {status}")

    h_inf = estimate_min_entropy(bits)
    print(f"\n{sep}")
    passed = sum(1 for r in results if r['pass'])
    print(f"Overall : {passed}/{len(results)} tests PASSED")
    print(f"Min entropy estimate: ≥ {h_inf:.2f} bits/sample")
    if all_pass:
        print("Verdict : Sequence appears RANDOM — suitable for NIST validation ✓")
    else:
        print("Verdict : One or more tests FAILED — investigate bias source")
    print(sep)


# ─────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="NIST SP 800-22 TRNG validation — Ring Oscillator TRNG project"
    )
    parser.add_argument("--input", type=str, default=None,
                        help="Path to bit sequence file (text, one bit per char or space-separated)")
    parser.add_argument("--generate", action="store_true",
                        help="Generate synthetic bits using Gaussian jitter model and run tests")
    parser.add_argument("--n", type=int, default=10000,
                        help="Number of bits to generate (default: 10000)")
    parser.add_argument("--sigma", type=float, default=50.0,
                        help="Jitter sigma in picoseconds for synthetic generation (default: 50)")
    args = parser.parse_args()

    script_dir = Path(__file__).parent
    default_bits_file = script_dir / "test_bits.txt"

    if args.generate:
        print(f"Generating {args.n:,} synthetic bits (Gaussian jitter model, σ={args.sigma}ps)...")
        bits = generate_simulated_bits(n=args.n, jitter_sigma_ps=args.sigma)
        save_bits(bits, str(default_bits_file))
    elif args.input:
        print(f"Loading bits from: {args.input}")
        bits = load_bits(args.input)
    elif default_bits_file.exists():
        print(f"Loading bits from: {default_bits_file}")
        bits = load_bits(str(default_bits_file))
    else:
        print("No bit file found. Generating synthetic bits (n=10,000)...")
        bits = generate_simulated_bits(n=10000)
        save_bits(bits, str(default_bits_file))

    print(f"Loaded {len(bits):,} bits. Running NIST tests...\n")
    results = run_all_tests(bits)
    print_results(results, bits)


if __name__ == "__main__":
    main()
