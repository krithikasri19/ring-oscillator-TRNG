# Simulation Setup Notes — Ring Oscillator TRNG

## Spectre Simulation Parameters

### Transient Analysis
```
.tran 1p 100n        ; 1ps step, 100ns window — captures ~65 oscillation cycles
```

### Operating Point
```
.op                  ; captures DC bias, transistor operating regions
```

### Power Analysis
```
; In Virtuoso ADE: Analyses → Transient → Save → All Voltages + Currents
; Post-process: Results → Direct Plot → Average Power
```

## Schematic Export Steps (Virtuoso → PNG)
1. Open schematic window
2. `File → Export → Image`
3. Format: PNG, Resolution: 150 dpi, Color: Color
4. Save to `../assets/schematic_ring_osc.png`

## Waveform Export Steps
1. Run transient simulation
2. In Waveform Viewer: select signals (net_RO1_out, net_RO2_out, trng_out)
3. `File → Print → Print to File → PDF`
4. Convert PDF → PNG using any tool
5. Save to `../assets/waveform_transient.png`

## Power Result Export
1. In ADE after transient run: `Results → Print → Current → vdd`
2. Screenshot the average current value
3. Save to `../assets/power_result.png`
